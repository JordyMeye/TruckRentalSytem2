//package za.ac.cput.controller;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.web.client.TestRestTemplate;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import za.ac.cput.domain.LoginDetail;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//class LoginDetailControllerTest {
//
//    @Autowired
//    private TestRestTemplate restTemplate;
//
//    private final String baseUrl = "http://localhost:8080/login-detail";  // Adjust URL as needed
//
//    private static final String ADMIN_EMAIL = "admin@example.com";
//    private static final String ADMIN_PASSWORD = "adminPassword123";
//
//    @Test
//    void loginWithValidCredentials() {
//        LoginDetail loginRequest = new LoginDetail();
//        loginRequest.setEmail(ADMIN_EMAIL);
//        loginRequest.setPassword(ADMIN_PASSWORD);
//
//        ResponseEntity<String> response = restTemplate.postForEntity(baseUrl, loginRequest, String.class);
//
//        //assertEquals(HttpStatus.OK, response.getStatusCode());
//        // Add more assertions based on your response structure or behavior
//    }
//
//    @Test
//    void loginWithInvalidCredentials() {
//        LoginDetail loginRequest = new LoginDetail();
//        loginRequest.setEmail("invalid@example.com");
//        loginRequest.setPassword("invalidPassword");
//
//        ResponseEntity<String> response = restTemplate.postForEntity(baseUrl, loginRequest, String.class);
//
//        //assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
//        // Add more assertions based on your response structure or behavior for invalid credentials
//    }
//
//    // ... (other test cases for login)
//}
