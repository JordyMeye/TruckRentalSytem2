//////package za.ac.cput.service.impl;
//////
//////import org.junit.jupiter.api.Test;
//////import org.junit.jupiter.api.TestMethodOrder;
//////import org.junit.jupiter.api.MethodOrderer;
//////import org.springframework.beans.factory.annotation.Autowired;
//////import org.springframework.boot.test.context.SpringBootTest;
//////
//////import za.ac.cput.domain.LoginDetail;
//////
//////import static org.junit.jupiter.api.Assertions.*;
//////
//////@TestMethodOrder(MethodOrderer.MethodName.class)
//////@SpringBootTest
//////class LoginDetailServiceImplTest {
//////
//////    @Autowired
//////    private LoginDetailServiceImpl loginDetailService;
//////
//////    @Test
//////    void a_login() {
//////        // Replace with valid email and password
//////        String email = "validemail@example.com";
//////        String password = "validpassword";
//////
//////        LoginDetail login = loginDetailService.loginDetail(email, password);
//////        assertNotNull(login);
//////        assertEquals(email, login.getEmail());
//////        assertEquals(password, login.getPassword());
//////    }
//////
//////    @Test
//////    void b_loginInvalid() {
//////        // Replace with invalid email and password
//////        String email = "invalidemail@example.com";
//////        String password = "invalidpassword";
//////
//////        LoginDetail login = loginDetailService.loginDetail(email, password);
//////        assertNull(login);
//////    }
//////}
////
////package za.ac.cput.service.impl;
////
////import org.junit.jupiter.api.Test;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.boot.test.context.SpringBootTest;
////import za.ac.cput.domain.Customer;
////import za.ac.cput.domain.LoginDetail;
////import za.ac.cput.service.CustomerService;
////import za.ac.cput.service.impl.LoginDetailServiceImpl;
////
////import static org.junit.jupiter.api.Assertions.assertEquals;
////import static org.junit.jupiter.api.Assertions.assertNotNull;
////import static org.mockito.Mockito.when;
////import static org.springframework.test.util.AssertionErrors.assertTrue;
////
////@SpringBootTest
////class LoginDetailServiceImplTest {
////
////    @Autowired
////    private LoginDetailServiceImpl loginDetailService;
////    private CustomerService customerService;
////
////    @Test
////    void testLoginWithExistingCustomer() {
////        // Mock an existing customer
////        Customer existingCustomer = new Customer();
////        existingCustomer.setEmail("perle@yahoo.fr");
////        existingCustomer.setPassword("2021");
////
////        // Mock the behavior of the customer repository
////        when(customerService.findByEmail("perle@yahoo.fr")).thenReturn(existingCustomer);
////
////        // Attempt to login with the existing customer's email and password
////        LoginDetail loginResult = loginDetailService.login("perle@yahoo.fr", "2021");
////
////        // Ensure the login was successful
////        //assertTrue(loginResult.isSuccess());
////        assertEquals(existingCustomer, loginResult.getEmail());
////    }
////}
//
//
//
//
//package za.ac.cput.service.impl;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import za.ac.cput.domain.Customer;
//import za.ac.cput.domain.LoginDetail;
//import za.ac.cput.service.CustomerService;
//
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.Mockito.when;
//
//@SpringBootTest
//class LoginDetailServiceImplTest {
//
//    @Autowired
//    private LoginDetailServiceImpl loginDetailService;
//    @Autowired
//    @MockBean
//    private CustomerService customerService;
//
//    @Test
//    void testLoginWithExistingCustomer() {
//        // Mock an existing customer
//        Customer existingCustomer = new Customer();
//        existingCustomer.setEmail("existing@example.com");
//        existingCustomer.setPassword("password123");
//
//        // Mock the behavior of the customer repository
////        when(customerService.findByEmail("existing@example.com")).thenReturn(existingCustomer);
//
//        // Attempt to login with the existing customer's email and password
//        LoginDetail loginResult = loginDetailService.login("existing@example.com", "password123");
//
//        // Ensure the login was successful
//        assertNotNull(loginResult);
//        assertEquals("existing@example.com", loginResult.getEmail());
//        assertEquals("password123", loginResult.getPassword());
//    }
//}
