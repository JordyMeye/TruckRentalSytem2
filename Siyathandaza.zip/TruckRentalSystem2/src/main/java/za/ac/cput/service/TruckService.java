package za.ac.cput.service;

import org.springframework.data.jpa.repository.JpaRepository;
import za.ac.cput.domain.Truck;

import java.util.Set;


public interface TruckService extends JpaRepository<Truck, Long> {
    public Set<Truck> getAll();
}
