//package za.ac.cput.service;
//
//public interface ReturnTruckService extends IService<ReturnTruck,String> {
