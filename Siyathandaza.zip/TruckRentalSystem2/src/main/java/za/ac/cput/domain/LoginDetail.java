/*
LoginDetail.java
2nd Domain entity
@Author: Siyakha Manisi (219239657)
09 April 2023
* */
package za.ac.cput.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.util.Objects;

@Entity
public class LoginDetail {
    @Id
    private String email;
    private String password;

    public LoginDetail(){

    }

    private LoginDetail(Builder builder)
    {
        this.email = builder.email;
        this.password = builder.password;

    }

    public String getEmail()
    {
        return email;
    }

    public String getPassword()
    {
        return password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object a)
    {
        if (this == a) return true;
        if (a == null || getClass() != a.getClass()) return false;
        LoginDetail ld = (LoginDetail) a;
        return Objects.equals(email, ld.email) && Objects.equals(password, ld.password);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(email, password);
    }

    @Override
    public String toString()
    {
        return "LoginDetail{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }


    public static class Builder
    {
        String email;
        String password;

        public Builder setUsername(String username)
        {
            this.email = username;
            return this;
        }

        public Builder setPassword(String password)
        {
            this.password = password;
            return this;
        }

        public Builder copy(LoginDetail ld)
        {
            this.email = ld.email;
            this.password = ld.password;
            return this;

        }

        public LoginDetail build()
        {
            return new LoginDetail(this);
        }
    }
}