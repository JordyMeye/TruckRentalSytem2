///*
//LoginDetail Service Interface
//LoginDetailService.java
//@Author: Siyakha Manisi (219239657)
//12 June 2023
//*/package za.ac.cput.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import za.ac.cput.domain.LoginDetail;
//
//import java.util.Set;
//
//public interface LoginDetailService extends IService<LoginDetail, String> {
//    //LoginDetail login(String email, String password);
//
//    // Define a setter method for CustomerService
//   // void setCustomerService(CustomerService customerService);
//}
