//package za.ac.cput.factory;
//
//
//
//import za.ac.cput.domain.LoginDetail;
//
//import za.ac.cput.util.Helper;
//
//
//
//public class LoginDetailFactory {
//
//    public static LoginDetail createLoginDetail(String email, String password) {
//
//        if (Helper.isNullorEmpty(email) || Helper.isNullorEmpty(password)) {
//
//            return null;
//
//        }
//
//        LoginDetail ld = new LoginDetail.Builder().setUsername(email)
//
//                .setPassword(password)
//
//                .build();
//
//        return ld;
//    }
//}
