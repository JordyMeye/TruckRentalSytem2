///*
//LoginDetail Service Implementation Class
//LoginDetailServiceImpl.java
//@Author: Siyakha Manisi (219239657)
//12 June 2023
//*/
//package za.ac.cput.service.impl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import za.ac.cput.domain.LoginDetail;
//import za.ac.cput.repository.ILoginDetailRepository;
//import za.ac.cput.service.CustomerService;
//import za.ac.cput.service.LoginDetailService;
//
//@Service
//public class LoginDetailServiceImpl implements LoginDetailService {
//
//    private ILoginDetailRepository repository;
//    private CustomerService customerService;
//
//    @Autowired
//    public LoginDetailServiceImpl(ILoginDetailRepository repository, CustomerService customerService) {
//        this.repository = repository;
//        this.customerService = customerService;
//    }
//
//    @Override
//    public LoginDetail login(String email, String password) {
//        // Implement login logic using the provided email and password
//        return repository.findByEmail(email);
//    }
//
//    @Override
//    public void setCustomerService(CustomerService customerService) {
//
//    }
//
//    @Override
//    public LoginDetail create(LoginDetail loginDetail) {
//        return null;
//    }
//
//    @Override
//    public LoginDetail read(String s) {
//        return null;
//    }
//
//    @Override
//    public LoginDetail update(LoginDetail loginDetail) {
//        return null;
//    }
//
//    @Override
//    public void delete(String s) {
//
//    }
//
//    // Implement other methods from LoginDetailService interface
//}
//

//
//
//
//
//
//
//
//
//    loginDetail(String email, String password) {
//        // Check if provided email and password match the admin login
//        if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
//            LoginDetail adminLogin = new LoginDetail();
//            adminLogin.setEmail(ADMIN_EMAIL);
//            adminLogin.setPassword(ADMIN_PASSWORD);
//            return adminLogin;
//        }
//
//        // If not admin login, check the database
//        return repository.findByEmail(email);
//    }
//
//}