///*
//LoginDetailController.java
//2nd Controller Entity
//@Author: Siyakha Manisi (219239657)
//09 April 2023
//* */
//package za.ac.cput.controller;
//
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import za.ac.cput.domain.LoginDetail;
//import za.ac.cput.service.LoginDetailService;
//import za.ac.cput.service.LoginDetailService;
//
//@RestController
//@RequestMapping("/login")
//public class LoginDetailController {
//    private final LoginDetailService service;
//
//    @Autowired
//    public LoginDetailController(LoginDetailService service) {
//        this.service = service;
//    }
//
//    @PostMapping("/customer/login")
//    public ResponseEntity<String> login(@RequestParam String email, @RequestParam String password) {
//        LoginDetail login = service.login(email, password);
//
//        if (login != null && login.getPassword().equals(password)) {
//            return ResponseEntity.ok("Login successful for email: " + login.getEmail());
//        } else {
//            return ResponseEntity.status(401).body("Login failed. Invalid email or password.");
//        }
//    }
//}
